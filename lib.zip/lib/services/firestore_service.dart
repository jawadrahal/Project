import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/product_model.dart';
import '../models/category_model.dart';
import '../models/order_model.dart';

class FirestoreService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  // Products
  Stream<List<ProductModel>> getProducts() {
    return _db.collection('products').snapshots().map((snapshot) {
      print('Products count: ${snapshot.docs.length}');
      return snapshot.docs
          .map((doc) => ProductModel.fromMap(doc.data(), doc.id))
          .toList();
    });
  }

  Future<void> addProduct(ProductModel product) async {
    try {
      await _db.collection('products').add(product.toMap());
      print('Product added successfully');
    } catch (e) {
      print('Error adding product: $e');
    }
  }

  Future<void> updateProductQuantity(String id, int quantity) async {
    try {
      await _db.collection('products').doc(id).update({'quantity': quantity});
      print('Quantity updated');
    } catch (e) {
      print('Error updating quantity: $e');
    }
  }

  Future<void> deleteProduct(String id) async {
    try {
      await _db.collection('products').doc(id).delete();
      print('Product deleted');
    } catch (e) {
      print('Error deleting product: $e');
    }
  }

  // Categories
  Stream<List<CategoryModel>> getCategories() {
    return _db.collection('categories').snapshots().map((snapshot) {
      return snapshot.docs
          .map((doc) => CategoryModel.fromMap(doc.data(), doc.id))
          .toList();
    });
  }

  Future<void> addCategory(CategoryModel category) async {
    try {
      await _db.collection('categories').add(category.toMap());
    } catch (e) {
      print('Error adding category: $e');
    }
  }

  // Orders
  Future<void> placeOrder(OrderModel order, String userId) async {
    try {
      await _db.collection('orders').add({
        ...order.toMap(),
        'userId': userId,
      });
      print('Order placed successfully');
    } catch (e) {
      print('Error placing order: $e');
    }
  }

  Stream<List<OrderModel>> getOrders() {
    return _db
        .collection('orders')
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snapshot) => snapshot.docs
        .map((doc) => OrderModel.fromMap(doc.data(), doc.id))
        .toList());
  }

  Stream<List<OrderModel>> getOrdersByUser(String userId) {
    return _db
        .collection('orders')
        .where('userId', isEqualTo: userId)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snapshot) => snapshot.docs
        .map((doc) => OrderModel.fromMap(doc.data(), doc.id))
        .toList());
  }
}