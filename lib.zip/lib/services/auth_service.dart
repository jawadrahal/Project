import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/account_model.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  Future<User?> signIn(String email, String password) async {
    try {
      UserCredential result = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      return result.user;
    } catch (e) {
      return null;
    }
  }

  Future<User?> register(String email, String password, String name, String phone) async {
    try {
      UserCredential result = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );
      await _db.collection('accounts').doc(result.user!.uid).set(
        AccountModel(
          id: result.user!.uid,
          name: name,
          phone: phone,
          address: '',
          state: '',
          role: 'customer',
        ).toMap(),
      );
      return result.user;
    } catch (e) {
      return null;
    }
  }

  Future<void> signOut() async => await _auth.signOut();

  User? get currentUser => _auth.currentUser;

  Future<AccountModel?> getCurrentAccount() async {
    try {
      final doc = await _db
          .collection('accounts')
          .doc(_auth.currentUser!.uid)
          .get();
      return AccountModel.fromMap(doc.data()!, doc.id);
    } catch (e) {
      return null;
    }
  }
}