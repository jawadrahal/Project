class AccountModel {
  final String id;
  final String name;
  final String phone;
  final String address;
  final String state;
  final String role;

  AccountModel({
    required this.id,
    required this.name,
    required this.phone,
    required this.address,
    required this.state,
    required this.role,
  });

  factory AccountModel.fromMap(Map<String, dynamic> map, String id) {
    return AccountModel(
      id: id,
      name: map['name'] ?? '',
      phone: map['phone'] ?? '',
      address: map['address'] ?? '',
      state: map['state'] ?? '',
      role: map['role'] ?? 'customer',
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'phone': phone,
      'address': address,
      'state': state,
      'role': role,
    };
  }
}