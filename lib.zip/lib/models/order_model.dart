class OrderModel {
  final String id;
  final String customerName;
  final String customerPhone;
  final String address;
  final int totalPrice;
  final String status;
  final List<Map<String, dynamic>> items;

  OrderModel({
    required this.id,
    required this.customerName,
    required this.customerPhone,
    required this.address,
    required this.totalPrice,
    required this.status,
    required this.items,
  });

  factory OrderModel.fromMap(Map<String, dynamic> map, String id) {
    return OrderModel(
      id: id,
      customerName: map['customerName'] ?? '',
      customerPhone: map['customerPhone'] ?? '',
      address: map['address'] ?? '',
      totalPrice: map['totalPrice'] ?? 0,
      status: map['status'] ?? 'pending',
      items: List<Map<String, dynamic>>.from(map['items'] ?? []),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'customerName': customerName,
      'customerPhone': customerPhone,
      'address': address,
      'totalPrice': totalPrice,
      'status': status,
      'items': items,
      'createdAt': DateTime.now(),
    };
  }
}