class CategoryModel {
  final String id;
  final String name;
  final String slug;
  final bool isVisible;

  CategoryModel({
    required this.id,
    required this.name,
    required this.slug,
    required this.isVisible,
  });

  factory CategoryModel.fromMap(Map<String, dynamic> map, String id) {
    return CategoryModel(
      id: id,
      name: map['name'] ?? '',
      slug: map['slug'] ?? '',
      isVisible: map['isVisible'] ?? true,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'slug': slug,
      'isVisible': isVisible,
    };
  }
}