class ProductModel {
  final String id;
  final String name;
  final String description;
  final int price;
  final int quantity;
  final String categoryId;
  final bool isAvailable;
  final List<String> images;

  ProductModel({
    required this.id,
    required this.name,
    required this.description,
    required this.price,
    required this.quantity,
    required this.categoryId,
    required this.isAvailable,
    required this.images,
  });

  factory ProductModel.fromMap(Map<String, dynamic> map, String id) {
    return ProductModel(
      id: id,
      name: map['name']?.toString() ?? '',
      description: map['description']?.toString() ?? '',
      price: (map['price'] is int) ? map['price'] : int.tryParse('${map['price']}') ?? 0,
      quantity: (map['quantity'] is int) ? map['quantity'] : int.tryParse('${map['quantity']}') ?? 0,
      categoryId: map['categoryId']?.toString() ?? '',
      isAvailable: (map['isAvailable'] is bool) ? map['isAvailable'] : true,
      images: (map['images'] is List)
          ? List<String>.from(map['images'].where((e) => e != null && e.toString().isNotEmpty))
          : [],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'description': description,
      'price': price,
      'quantity': quantity,
      'categoryId': categoryId,
      'isAvailable': isAvailable,
      'images': images,
      'createdAt': DateTime.now(),
    };
  }
}