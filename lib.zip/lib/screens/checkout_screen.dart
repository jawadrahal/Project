import 'package:flutter/material.dart';
import '../models/product_model.dart';
import '../models/order_model.dart';
import '../services/firestore_service.dart';
import '../services/auth_service.dart';

class CheckoutScreen extends StatefulWidget {
  final List<Map<String, dynamic>> cart;
  final int total;
  final VoidCallback onOrderPlaced;

  const CheckoutScreen({
    super.key,
    required this.cart,
    required this.total,
    required this.onOrderPlaced,
  });

  @override
  State<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  final _nameController = TextEditingController();
  final _phoneController = TextEditingController();
  final _addressController = TextEditingController();
  final _firestoreService = FirestoreService();
  final _authService = AuthService();
  String _paymentMethod = 'cash';
  bool _isLoading = false;

  void _placeOrder() async {
    if (_nameController.text.isEmpty ||
        _phoneController.text.isEmpty ||
        _addressController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('الرجاء ملء جميع الحقول')));
      return;
    }
    setState(() => _isLoading = true);

    // تحديث الكمية في Firestore
    for (var item in widget.cart) {
      final product = item['product'] as ProductModel;
      final quantity = item['quantity'] as int;
      final newQuantity = product.quantity - quantity;
      await _firestoreService.updateProductQuantity(
          product.id, newQuantity < 0 ? 0 : newQuantity);
    }

    // حفظ الطلب
    final order = OrderModel(
      id: '',
      customerName: _nameController.text.trim(),
      customerPhone: _phoneController.text.trim(),
      address: _addressController.text.trim(),
      totalPrice: widget.total,
      status: 'pending',
      items: widget.cart.map((item) {
        final product = item['product'] as ProductModel;
        return {
          'name': product.name,
          'price': product.price,
          'quantity': item['quantity'],
          'id': product.id,
        };
      }).toList(),
    );

    await _firestoreService.placeOrder(
        order, _authService.currentUser?.uid ?? '');

    setState(() => _isLoading = false);

    // مسح السلة
    widget.onOrderPlaced();

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        title: const Text('ORDER PLACED! 🎉',
            style: TextStyle(letterSpacing: 1)),
        content: const Text('سيتم التواصل معك قريباً'),
        actions: [
          TextButton(
            onPressed: () =>
                Navigator.popUntil(context, (route) => route.isFirst),
            child: const Text('OK',
                style: TextStyle(color: Colors.black, letterSpacing: 1)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.black),
        title: const Text(
          'CHECKOUT',
          style: TextStyle(
            color: Colors.black,
            fontWeight: FontWeight.bold,
            letterSpacing: 3,
            fontSize: 14,
          ),
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('DELIVERY INFORMATION',
                style: TextStyle(
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2,
                    fontSize: 12)),
            const SizedBox(height: 16),
            TextField(
              controller: _nameController,
              decoration: InputDecoration(
                labelText: 'الاسم الكامل',
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(4)),
                focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(4),
                    borderSide:
                    const BorderSide(color: Colors.black, width: 2)),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _phoneController,
              keyboardType: TextInputType.phone,
              decoration: InputDecoration(
                labelText: 'رقم الهاتف',
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(4)),
                focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(4),
                    borderSide:
                    const BorderSide(color: Colors.black, width: 2)),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _addressController,
              maxLines: 3,
              decoration: InputDecoration(
                labelText: 'العنوان',
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(4)),
                focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(4),
                    borderSide:
                    const BorderSide(color: Colors.black, width: 2)),
              ),
            ),
            const SizedBox(height: 24),
            const Text('PAYMENT METHOD',
                style: TextStyle(
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2,
                    fontSize: 12)),
            const SizedBox(height: 8),
            RadioListTile(
              value: 'cash',
              groupValue: _paymentMethod,
              onChanged: (v) => setState(() => _paymentMethod = v!),
              title: const Text('الدفع عند الاستلام'),
              activeColor: Colors.black,
              contentPadding: EdgeInsets.zero,
            ),
            RadioListTile(
              value: 'card',
              groupValue: _paymentMethod,
              onChanged: (v) => setState(() => _paymentMethod = v!),
              title: const Text('بطاقة بنكية'),
              activeColor: Colors.black,
              contentPadding: EdgeInsets.zero,
            ),
            const SizedBox(height: 24),
            const Divider(),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('ORDER TOTAL',
                    style: TextStyle(
                        fontWeight: FontWeight.bold, letterSpacing: 1)),
                Text('${widget.total} دج',
                    style: const TextStyle(
                        fontWeight: FontWeight.bold, fontSize: 18)),
              ],
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton(
                onPressed: _isLoading ? null : _placeOrder,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.black,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(4)),
                ),
                child: _isLoading
                    ? const CircularProgressIndicator(color: Colors.white)
                    : const Text(
                  'PLACE ORDER',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    letterSpacing: 2,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}